export default function Components () {

    return (
        <>
            <h1>Страница компонентов</h1>
        </>
    );
}
